<footer class="footer px-4">
    <div class="small text-center">
        Created by&nbsp;
        <a href="https://amarzyo.github.io">amarzyo</a>
        {{-- <a href="https://coreui.io">CoreUI </a>
        <a href="https://coreui.io/product/free-bootstrap-admin-template/">
            Bootstrap Admin Template
        </a> --}}
        &copy; 2025 | CoreUI UI Components
    </div>
    {{-- <div class="ms-auto">
        Powered by&nbsp;
        <a href="https://coreui.io/bootstrap/docs/">
            CoreUI UI Components
        </a>
    </div> --}}
</footer>
