<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-header">
            <h6 class="my-0">DASHBOARD</h6>
        </div>
        <div class="card-body">
            Selamat datang di halaman dashboard. <span class="text-primary"><?php echo e($admin->name); ?></span>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Web App\Laravel Herd Project\sw\resources\views/dashboard/index.blade.php ENDPATH**/ ?>