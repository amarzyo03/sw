<footer class="footer px-4">
    <div class="small text-center">
        Created by&nbsp;
        <a href="https://amarzyo.github.io">amarzyo</a>
        
        &copy; 2025 | CoreUI UI Components
    </div>
    
</footer>
<?php /**PATH F:\Web App\Laravel Herd Project\sw\resources\views/component/footer.blade.php ENDPATH**/ ?>