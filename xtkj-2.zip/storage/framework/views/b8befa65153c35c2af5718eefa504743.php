<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h6 class="my-0">Rapor PSAS Ganjil</h6>
                <h6 class="my-0">
                    <a href="/ganjil/psts/nilai-murni/export" class="btn btn-sm btn-danger text-white" target="_blank">
                        Export PDF
                    </a>
                </h6>
            </div>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm table-hover table-bordered text-center">
                    <thead class="text-nowrap">
                        <tr class="align-middle">
                            <th scope="col" rowspan="2">#</th>
                            <th scope="col" rowspan="2">Nama</th>
                            <th scope="col" colspan="12">Mata Pelajaran</th>
                            <th scope="col" rowspan="2">Jumlah</th>
                            <th scope="col" rowspan="2">Rata-rata</th>
                            <th scope="col" rowspan="2">Rank</th>
                        </tr>
                        <tr class="align-middle">
                            <th scope="col">AGM</th>
                            <th scope="col">PANC</th>
                            <th scope="col">INDO</th>
                            <th scope="col">PJOK</th>
                            <th scope="col">SEJ</th>
                            <th scope="col">MTK</th>
                            <th scope="col">INGG</th>
                            <th scope="col">INFO</th>
                            <th scope="col">PIPAS</th>
                            <th scope="col">DDK</th>
                            <th scope="col">KKA</th>
                            <th scope="col">JWA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php echo e($row->rank == 1 || $row->rank == 2 || $row->rank == 3 ? 'table-success' : ''); ?>">
                                <td><?php echo e($i + 1); ?></td>
                                <td class="text-nowrap text-start text-capitalize"><?php echo e($row->siswa->nama); ?></td>
                                <td><?php echo e($row->agm); ?></td>
                                <td><?php echo e($row->panc); ?></td>
                                <td><?php echo e($row->indo); ?></td>
                                <td><?php echo e($row->pjok); ?></td>
                                <td><?php echo e($row->sej); ?></td>
                                <td><?php echo e($row->ingg); ?></td>
                                <td><?php echo e($row->info); ?></td>
                                <td><?php echo e($row->pipas); ?></td>
                                <td><?php echo e($row->ddk); ?></td>
                                <td><?php echo e($row->kka); ?></td>
                                <td><?php echo e($row->jwa); ?></td>
                                <td><?php echo e($row->ddk); ?></td>
                                <td><?php echo e($row->jml); ?></td>
                                <td><?php echo e($row->rerata); ?></td>
                                <td><?php echo e($row->rank); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="23" class="bg-secondary">
                                    Tidak ada data
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Web App\Laravel Herd Project\sw\resources\views/ganjil/rapor.blade.php ENDPATH**/ ?>