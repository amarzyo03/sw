<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h6 class="my-0">DATA SISWA</h6>
                <h6 class="my-0">
                    <a href="<?php echo e(route('siswa.create')); ?>" class="btn btn-sm btn-success text-white">
                        TAMBAH SISWA
                    </a>
                </h6>
            </div>

        </div>

        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <span class="my-0">Jumlah Siswa : <?php echo e($data->total()); ?> | L : <?php echo e($laki); ?> - P : <?php echo e($perempuan); ?> |</span>
                <form action="<?php echo e(route('siswa.index')); ?>" method="GET" class="d-flex" role="search">
                    <div class="input-group input-group-sm">
                        <input type="text" class="form-control" placeholder="Pencarian..." name="search" value="<?php echo e(request()->get('search')); ?>">
                        <button class="btn btn-primary" type="submit">Cari</button>
                    </div>
                </form>
            </div>
            <table class="table table-hover table-striped table-bordered mt-3">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">NIS</th>
                        <th scope="col">NAMA</th>
                        <th scope="col">Telp</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration + ($data->currentPage() - 1) * $data->perPage()); ?></th>
                            <td><?php echo e($row->nis); ?></td>
                            <td><?php echo e(ucwords($row->nama)); ?></td>
                            <td><?php echo e($row->telp); ?></td>
                            <td>
                                <div class="btn-group-vertical" role="group" aria-label="Vertical button group">
                                    <div class="btn-group btn-group-sm " role="group">
                                        <button id="btnGroupVerticalDrop1" type="button" class="btn btn-primary dropdown-toggle" data-coreui-toggle="dropdown" aria-expanded="false">
                                            menu
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="btnGroupVerticalDrop1">
                                            <li><a class="dropdown-item text-primary" href="<?php echo e(route('siswa.show', $row->id)); ?>">Detail</a></li>
                                            <li><a class="dropdown-item text-warning" href="<?php echo e(route('siswa.edit', $row->id)); ?>">Edit</a></li>
                                            <form action="<?php echo e(route('siswa.destroy', $row->id)); ?>" method="post" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <li>
                                                    <button type="submit" class="dropdown-item btn btn-link text-danger">Delete</button>
                                                </li>
                                            </form>
                                        </ul>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="flex justify-content-ened">
                <?php echo e($data->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Web App\Laravel Herd Project\sw\resources\views/siswa/index.blade.php ENDPATH**/ ?>