<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h6 class="my-0">Presensi</h6>
                <h6 class="my-0">
                    <div class="btn-group btn-group-sm" role="group">
                        <a href="<?php echo e(route('presensi.edit')); ?>" class="btn btn-warning">Edit</a>
                        <a href="#" class="btn btn-danger">Export PDF</a>
                    </div>
                </h6>
            </div>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover table-sm">
                    <thead>
                        <tr>
                            <th rowspan="2" class="align-middle text-center">No</th>
                            <th rowspan="2" class="align-middle text-center">Nama Siswa</th>
                            <th colspan="3" class="text-center">Kehadiran</th>
                        </tr>
                        <tr>
                            <th class="text-center">Sakit</th>
                            <th class="text-center">Izin</th>
                            <th class="text-center">Alfa</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($i + 1); ?></td>
                                <td class="text-capitalize"><?php echo e($row->siswa->nama); ?></td>
                                <td class="text-center"><?php echo e($row->sakit); ?></td>
                                <td class="text-center"><?php echo e($row->izin); ?></td>
                                <td class="text-center"><?php echo e($row->alpa); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Web App\Laravel Herd Project\sw\resources\views/presensi/index.blade.php ENDPATH**/ ?>