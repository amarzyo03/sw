<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h6 class="my-0">Presensi</h6>
                <h6 class="my-0">
                    <a href="<?php echo e(route('presensi.index')); ?>" class="btn btn-sm btn-secondary">Kembali</a>
                </h6>
            </div>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover table-sm">
                    <thead>
                        <tr>
                            <th rowspan="2" class="align-middle text-center">No</th>
                            <th rowspan="2" class="align-middle text-center">Nama Siswa</th>
                            <th colspan="3" class="text-center">Kehadiran</th>
                        </tr>
                        <tr>
                            <th class="text-center">Sakit</th>
                            <th class="text-center">Izin</th>
                            <th class="text-center">Alfa</th>
                        </tr>
                    </thead>
                    <tbody>
                        <form action="<?php echo e(route('presensi.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($i + 1); ?></td>
                                    <td class="text-capitalize"><?php echo e($row->siswa->nama); ?></td>
                                    <td class="text-center">
                                        <input type="hidden" name="id[]" value="<?php echo e($row->id); ?>">
                                        <input type="number" name="sakit[]" value="<?php echo e($row->sakit); ?>"
                                            class="form-control form-control-sm text-center">
                                    </td>
                                    <td class="text-center">
                                        <input type="number" name="izin[]" value="<?php echo e($row->izin); ?>"
                                            class="form-control form-control-sm text-center">
                                    </td>
                                    <td class="text-center">
                                        <input type="number" name="alpa[]" value="<?php echo e($row->alpa); ?>"
                                            class="form-control form-control-sm text-center">
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="5" class="text-end">
                                    <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                                </td>
                            </tr>
                        </form>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Web App\Laravel Herd Project\sw\resources\views/presensi/edit.blade.php ENDPATH**/ ?>